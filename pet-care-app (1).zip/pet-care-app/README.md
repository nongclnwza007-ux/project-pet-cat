# Pet Care App (Taiwan demo)

A demo web app for pet owners: pet profiles, health records, breed guides, an AI assistant that says how urgent a symptom sounds, and sample screens for clinics, hotels, food and pet life stages. Built to pitch for a university startup fund. See `.scratch/pet-care-demo/spec.md` for the full spec and `.scratch/pet-care-demo/issues/` for the tickets.

## Run it

1. Install Node.js, then in this folder run `npm install` once.
2. Copy `.env.example` to `.env.local` and keep `PET_APP_DEMO=1` for the demo.
3. Run `npm run dev`, then open http://localhost:3000 in a browser.
4. On the sign-in page press **Try the demo**. It opens a ready-made account with one pet for each breed guide, and a **Reset demo** button on the home page restores it.

Without an `ANTHROPIC_API_KEY` the AI chat still works, but it answers with built-in safe guidance instead of a model's text. Set `PET_APP_FAKE_LLM=1` to get a fixed fake model reply, which is what the tests use.

Windows PowerShell without a `.env.local`: `$env:PET_APP_DEMO = "1"; npm run dev`.

## Tests

`npm run e2e` runs all the tests. The tests start their own server on port 3100 unless one is already running there.

## What is real and what is a shortcut

- Real: sign-up and sign-in, pets with photos, health records with due dates, breed guides, AI triage with safety rules, English / Traditional Chinese / Thai interface.
- Sample only: clinics, hotels, restaurants and life-stage screens. Every name is made up.
- Shortcut: accounts, pets and records are JSON files under `.data/`. Replace them with a real database (for example Supabase) before real owners use the app.
- Breed guide content is English only, not yet reviewed by a licensed vet, and its sources are named references, not checked pages. A vet must sign off before it is called verified.
- Translations are a first draft and need review by a native speaker.
- The demo account has a public password. Never set `PET_APP_DEMO=1` on a deployment that holds real owners' data.
- The AI never diagnoses or recommends medicine. This is enforced in code (`src/lib/triage.ts`), not only in the model's prompt.
