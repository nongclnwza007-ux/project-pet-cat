import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  cacheComponents: true,
  partialPrefetching: true,
  // photos are capped at 5 MB in createPet; the default 1 MB would reject them first
  experimental: { serverActions: { bodySizeLimit: "6mb" } },
};

export default nextConfig;
