import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  workers: 1,
  use: { baseURL: "http://localhost:3100" },
  projects: [{ name: "phone", use: { ...devices["Pixel 7"] } }],
  webServer: {
    command: "npm run dev -- -p 3100",
    url: "http://localhost:3100",
    reuseExistingServer: true,
    env: { PET_APP_DATA_FILE: ".data/test-users.json", PET_APP_PETS_FILE: ".data/test/pets.json", PET_APP_HEALTH_FILE: ".data/test/health.json", PET_APP_FAKE_LLM: "1", PET_APP_DEMO: "1" },
  },
});
